<?php
/* Smarty version 4.5.3, created on 2026-10-01 07:18:38
  from 'C:\xampp\htdocs\phpnuxbill-master\ui\ui\admin\odp\list.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6abda6de09ec02_44008276',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eee138c6e763c29079a4538feda8fd76592ae33c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill-master\\ui\\ui\\admin\\odp\\list.tpl',
      1 => 1790662250,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:sections/header.tpl' => 1,
    'file:pagination.tpl' => 1,
    'file:sections/footer.tpl' => 1,
  ),
),false)) {
function content_6abda6de09ec02_44008276 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:sections/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
<!-- odp -->
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-hovered mb20 panel-primary">
            <div class="panel-heading">
                <?php echo Lang::T('Optical Distribution Point List');?>

            </div>
            <div class="panel-body">
                <div class="md-whiteframe-z1 mb20 text-center" style="padding: 15px">
                    <div class="col-md-8">
                        <form id="site-search" method="post" action="<?php echo Text::url('');?>
odp/list/">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-search"></span>
                                </div>
                                <input type="text" name="name" class="form-control"
                                    placeholder="<?php echo Lang::T('Search by Name');?>
..." value="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
>
                                <div class="input-group-btn">
                                    <button class="btn btn-success" type="submit"><?php echo Lang::T('Search');?>
</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <a href="<?php echo Text::url('');?>
odp/add" class="btn btn-primary btn-block"><i
                                class="ion ion-android-add"> </i> <?php echo Lang::T('New odp');?>
</a>
                    </div>&nbsp;
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-condensed">
                        <thead>
                            <tr>
                                <th><?php echo Lang::T('Name');?>
</th>
                                <th><?php echo Lang::T('Port Amount');?>
</th>
                                <th><?php echo Lang::T('Attenuation');?>
</th>
                                <th><?php echo Lang::T('Address');?>
</th>
                                <th><?php echo Lang::T('Covarage');?>
</th>
                                <th><?php echo Lang::T('Coordinates');?>
</th>
                                <th><?php echo Lang::T('Action');?>
</th>
                                <th>ID</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['d']->value, 'ds');
$_smarty_tpl->tpl_vars['ds']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['ds']->value) {
$_smarty_tpl->tpl_vars['ds']->do_else = false;
?>
                                <tr>
                                    <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['name'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['port_amount'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['attenuation'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['address'];?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['coverage'];?>
 m</td>
                                    <td align="center">
                                        <?php if ($_smarty_tpl->tpl_vars['ds']->value['coordinates']) {?>
                                        <a href="https://www.google.com/maps/dir//<?php echo $_smarty_tpl->tpl_vars['ds']->value['coordinates'];?>
/" target="_blank"
                                            class="btn btn-default btn-xs" title="<?php echo $_smarty_tpl->tpl_vars['ds']->value['coordinates'];?>
"><i
                                                class="glyphicon glyphicon-map-marker"></i></a>
                                        <?php }?>
                                    </td>
                                    <td align="center">
                                        <a href="<?php echo Text::url('');?>
odp/edit/<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
" class="btn btn-primary btn-xs"
                                            title="<?php echo Lang::T('Edit');?>
"><i class="glyphicon glyphicon-edit"></i></a>
                                        <a href="<?php echo Text::url('');?>
odp/delete/<?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
" class="btn btn-danger btn-xs"
                                            onclick="return ask(this, '<?php echo Lang::T('Are you sure you want to delete this ODP?');?>
')" title="<?php echo Lang::T('Delete');?>
"><i
                                                class="glyphicon glyphicon-trash"></i></a>
                                    </td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['ds']->value['id'];?>
</td>
                                </tr>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </tbody>
                    </table>
                </div>
                <?php $_smarty_tpl->_subTemplateRender("file:pagination.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
            </div>
        </div>
    </div>
</div>

<?php $_smarty_tpl->_subTemplateRender("file:sections/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
