<?php
/* Smarty version 4.5.3, created on 2026-10-01 07:07:25
  from 'C:\xampp\htdocs\phpnuxbill-master\ui\ui\sections\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6abda43d2d37b0_62482365',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c9ae365b54b0d5c3532c01423e08f07502841acd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill-master\\ui\\ui\\sections\\footer.tpl',
      1 => 1790662250,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/footer.tpl' => 1,
  ),
),false)) {
function content_6abda43d2d37b0_62482365 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
