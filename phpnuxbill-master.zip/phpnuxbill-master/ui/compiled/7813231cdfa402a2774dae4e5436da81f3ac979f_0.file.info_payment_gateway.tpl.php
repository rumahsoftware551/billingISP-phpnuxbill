<?php
/* Smarty version 4.5.3, created on 2026-10-01 07:07:23
  from 'C:\xampp\htdocs\phpnuxbill-master\ui\ui\widget\info_payment_gateway.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6abda43b76b850_04501170',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7813231cdfa402a2774dae4e5436da81f3ac979f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill-master\\ui\\ui\\widget\\info_payment_gateway.tpl',
      1 => 1790662250,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6abda43b76b850_04501170 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="panel panel-success panel-hovered mb20 activities">
    <div class="panel-heading"><?php echo Lang::T('Payment Gateway');?>
: <?php echo str_replace(',',', ',$_smarty_tpl->tpl_vars['_c']->value['payment_gateway']);?>

    </div>
</div><?php }
}
