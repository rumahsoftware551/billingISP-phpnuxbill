<?php
/* Smarty version 4.5.3, created on 2026-10-01 07:07:24
  from 'C:\xampp\htdocs\phpnuxbill-master\ui\ui\sections\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.5.3',
  'unifunc' => 'content_6abda43c3936f3_38869668',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7733e5504a4291d310c492548cdcc5d168c20bd3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\phpnuxbill-master\\ui\\ui\\sections\\header.tpl',
      1 => 1790662250,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/header.tpl' => 1,
  ),
),false)) {
function content_6abda43c3936f3_38869668 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:admin/header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
